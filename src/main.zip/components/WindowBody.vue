<template>
  <main class="main">
    <div class="main__chat" v-for="(mess, index) in messages" :key="index">
      <div class="main__chat-body send" v-if="mess.sendId == id">
        <span class="main__chat-time">{{ mess.time }}</span>
        <div class="main__chat-text">
          <img :src="mess.photo" v-if="mess.photo.length > 0" alt="" />
          <p>{{ mess.body }}</p>
        </div>
      </div>
      <div class="main__chat-body get" v-else>
        <div class="main__chat-text">
          <img :src="mess.photo" v-if="mess.photo.length > 0" alt="" />
          <p>{{ mess.body }}</p>
        </div>
        <span class="main__chat-time">{{ mess.time }}</span>
      </div>
    </div>
  </main>
</template>

<script>
export default {
  name: "WindowBody",
  props: {
    id: Number,
    messages: Array,
  },
};
</script>